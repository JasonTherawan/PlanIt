import backarrowButton from './back-arrow-button.png'
import backButton from './back-button.png'
import binIcon from './bin-icon.png'
import closeIcon from './close-icon.png'
import copyIcon from './copy-icon.png'
import editIcon from './edit-icon.png'
import logoutIcon from './log-out-icon.png'
import teamIcon from './team-icon.png'

export {
    backarrowButton,
    backButton,
    binIcon,
    closeIcon,
    copyIcon,
    editIcon,
    logoutIcon,
    teamIcon
};
